#include<iostream>
#include<climits>
#include<math.h>
#include<cmath>
#include<algorithm>

using namespace std;

int rodCutting(int value[])
{
	int i, j;
	int result[6];
	result[0] = 0;

	
	for (i = 1; i <= 5; i++)
	{
		result[i] = INT_MIN;

		
		for (j = 0; j<i; j++)
		{
			result[i] = max(result[i], value[j] + result[i - (j + 1)]);
		}
	}


	return result[5];
}

int main()
{
	

	int value[5];
	cout << "Enter the values of pieces of rod of all size" << endl;

	for (int i = 0; i<5; i++)
		cin >> value[i];

	cout << "Maximum obtainable value by cutting up the rod in many pieces are" << endl;
	cout << rodCutting(value);

	cout << endl;
	system("pause");
}