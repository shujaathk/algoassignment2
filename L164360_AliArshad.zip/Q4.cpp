#include <iostream> 
using namespace std;

int missingsearch(int arr[], int size)
{
	int a = 0,
		b = size - 1;
	int mid;
	while ((b - a) > 1)
	{
		mid = (a + b) / 2;
		if ((arr[a] - a) != (arr[mid] - mid))
			b = mid;
		else if ((arr[b] - b) != (arr[mid] - mid))
			a = mid;
	}
	return (arr[mid] + 1);
}

int main()
{
	int arr[] = { 1, 2, 3, 4, 5, 6,7,8,10 };
	int size = sizeof(arr) / sizeof(arr[0]);
	cout << "Missing number:" << missingsearch(arr, size) << endl;
}