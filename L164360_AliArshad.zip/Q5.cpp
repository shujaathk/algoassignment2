#include<iostream> 
using namespace std;
int max_element(int a, int b)
{
	if (a > b)
		return a;
	else
		return b;
}

int sub(int arr[], int n)
{
	int lis[n];
	lis[0] = 1;
	for (int i = 1; i < n; i++)
	{
		lis[i] = 1;
		for (int j = 0; j < i; j++)
			if (arr[i] > arr[j] && lis[i] < lis[j] + 1)
				lis[i] = lis[j] + 1;
	}
	return max_element(lis, lis + n);
}
int main()
{
	int arr[] = { 1, 5, 6, 4, 7, 3, 2, 4, 8, 9 };
	int n = sizeof(arr) / sizeof(arr[0]);
	//printf("Length of lis is %d\n", sub( arr, n));
	cout << "Length of SubSequence is " + sub(arr, n);
	return 0;
}