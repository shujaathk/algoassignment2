#include<iostream>
using namespace std;

int chess(int a, int b)
{
	if (a == 7 || b == 7)
		return 1;
	else
		return next(a, b + 1) + next(a + 1, b);
}

int main()
{
	cout << "The shortest number of paths a rook can move from one corner of a chessboard to opposite side are "<<chess(0,0);
}