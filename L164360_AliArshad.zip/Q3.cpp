#include <iostream>
#include<string>
using namespace std;
int max(int a, int b)
{
	if (a > b)
		return a;
	else
		return b;
}

int LPS(string str, int a, int b)
{
	if (a > b)
		return 0;
	if (a == b)
		return 1;
	if (str[a] == str[b])
		return 2 + LPS(str, a + 1, b - 1);
	return max(LPS(str, a + 1, b), LPS(str, a, b - 1));
}

int main()

{
	string str;
	cout << "Please enter the string: ";
	cin >> str;

	int len = sizeof(str);

	int b = len - 1;

	int a = 0;

	cout << LPS(str, a, b);

	return 0;
}