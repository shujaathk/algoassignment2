#include <iostream>
#include <string>
using namespace std;
int max(int a, int b){
	if (a > b){
		return a;
	}
	else{
		return b;
	}
}

void LIS(int arr[], int n){
	int *arr2 = new int[n];  //maintaining length
	int *arr3 = new int[n];  //finding subsequence

	for (int i = 0; i < n; i++){
		arr2[i] = 1;
	}

	for (int i = 1; i < n; i++){
		for (int j = 0; j < i; j++){
			if (arr[i]>arr[j]){
				arr2[i] = max(1 + arr2[j], arr2[i]);
				if (1 + arr2[j] >= arr2[i]){
					arr3[i] = j;
				}
			}
		}
	}
	int size = arr2[n - 1];
	cout << "length of longest common subsequence is: " << size << endl;

	int *arr4 = new int[size];
	int j = size - 1;
	int i = n - 1;
	while (j >= 0){
		arr4[j] = i;
		j--;
		i = arr3[i];
	}
	cout << "the longest common subsequence is:" << endl;
	for (int i = 0; i < size; i++){
		cout << arr[arr4[i]] << endl;
	}
}

int main()
{
	int i, j;
	int arr[] = { 1, 5, 6, 4, 7, 3, 2, 4, 8, 9 };
	int n = 10;
	LIS(arr, n);
	return 0;
}


/*
complexity analysis:
the above code is working in following manner:
1)it is maintaining two arrays of same size as the given array. Firstr array maintains the lengths and 2nd one
maintains the subsequences, this is done using two for loops therefore the complexity=0(n^2)
2)then an array of size equal to maximum length obtained from the length maintaining array is formed and its elements
are inserted on the basis of indexes from the array maintaining subsequences and finally that array is printed.
so complexity of this step is 0(n).
overall complexity =0(n+n+n^2)
                   =0(n^2)


*/