#include<iostream> 
#include <string>
using namespace std;
int max(int x, int y)              //max helper function
{
	if (x > y){
		return x;
	}
	else{
		return y;
	}
}

string palindrome(string &X, string &Y) //X is the given string and Y is the given string in reversed form
{                                         //longest common subsequence technique is applied on X and Y
	int m = X.length();
	int n = Y.length();
	int** L = new int*[m + 1];
	for (int i = 0; i <= m; ++i){
		L[i] = new int[n + 1];
	}

	for (int i = 0; i <= m; i++)
	{
		for (int j = 0; j <= n; j++)
		{
			if (i == 0 || j == 0){
				L[i][j] = 0;
			}
			else if (X[i - 1] == Y[j - 1]){
				L[i][j] = L[i - 1][j - 1] + 1;
			}
			else{
				L[i][j] = max(L[i - 1][j], L[i][j - 1]);
			}
		}
	}
	//printing of longest common subsequence
	int index = L[m][n];


	string palindrome(index + 1, '\0');


	int i = m, j = n;
	while (i > 0 && j > 0)
	{

		if (X[i - 1] == Y[j - 1])
		{

			palindrome[index - 1] = X[i - 1];
			i--;
			j--;


			index--;
		}

		else if (L[i - 1][j] > L[i][j - 1])
			i--;
		else
			j--;
	}

	return palindrome;
}



int main()
{
	string str = "character";
	string rev = str;
	reverse(rev.begin(), rev.end());

	cout << palindrome(str, rev);

	return 0;
}

/*
Time complexity analysis for above code:
In above code we have used the longest common subsequence technique on the two strings. i.e; the original string and reversed form
of the original string.
As we know the time complexity for longest common subsequence is 0(mn) where m=length of string and n=length of reversed string.
so, overall complexity of our code will be 0(mn).
*/