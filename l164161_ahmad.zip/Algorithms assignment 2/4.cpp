#include <iostream> 
using namespace std;

int findmissing(int sar[], int N)
{
	int start = 0, end = N - 1;
	while (end - start >= 0) {

		int mid = (start + end) / 2;

		if (sar[mid] != mid + 1 && sar[mid - 1] == mid){
			return mid + 1;
		}
		if (sar[mid] != mid + 1){
			end = mid - 1;
		}

		else{
			start = mid + 1;
		}
	}

	return -1;
}

// Driver code 
void main()
{
	int arr[] = { 1, 2, 3, 5, 6, 7, 8, 9 };
	int N = sizeof(arr) / sizeof(arr[0]);
	int a = findmissing(arr, N);
	cout << "Missing element is:" << a << endl;
}

/*
Time complexity code for above code:
In above code we have used the divide and conquer technique where in every step
problem is divided into two halves, as the complexity for
divide and conquer technique is 0(logn) thefore the complexity for our missing number problem
algorithm is also 0(logn)
*/