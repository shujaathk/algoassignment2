#include <iostream>
using namespace std;
void Chess(int **arr,int m, int n){

	for (int i = 1; i <= m; i++){
		for (int j = 1; j <= n; j++){
			arr[i][j] = 1;
		}
	}

	for (int i = 2; i <= m; i++){
		for (int j = 2; j <= n; j++ ){
			arr[i][j] = (arr[i][j - 1]) + (arr[i-1][j]);
		}
	}
}

void Print(int **arr, int m, int n){
	for (int i = 1; i <= m; i++){
		for (int j = 1; j <= n; j++){
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

void main(){
	int m = 8;
	int n = 8;
	int** l = new int*[m];
	for (int i = 0; i <= m; ++i){
		l[i] = new int[n];
	}
	Chess(l, m, n);
	Print(l, m, n);
	}

/*
time complexity for above code is 0(mn)
i.e; rows multiply by columns.

*/