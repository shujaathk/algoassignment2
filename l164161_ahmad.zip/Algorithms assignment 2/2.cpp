#include <iostream>
using namespace std;

struct Item {
	int rate;
	int length;
	float density;
};

void input(Item items[], int sizeOfItems){
	for (int i = 0; i<sizeOfItems; i++){
		cout << "Enter " << i + 1 << " length" << endl;
		cin >> items[i].length;
		cout << "Enter " << i + 1 << " rate " << endl;
		cin >> items[i].rate;
	}
}




float WIRE(Item items[], int sizeOfItems, int L){
	int i, j, pos;
	Item mx, temp;
	float totalrate = 0, totallength = 0;


	for (i = 0; i<sizeOfItems; i++){
		items[i].density = items[i].rate / items[i].length;
	}




	//sorting

	for (i = 0; i<sizeOfItems; i++){
		mx = items[i];
		pos = i;
		for (j = i; j<sizeOfItems; j++){
			if (items[j].density> mx.density){
				mx = items[j];
				pos = j;
			}
		}
		temp = items[i];
		items[i] = mx;
		items[pos] = temp;
	}



	for (i = 0; i<sizeOfItems; i++){
		if (totallength + items[i].length <= L){
			totalrate += items[i].rate;
			totallength += items[i].length;
		}
		else {
			int lt = L - totallength;
			totalrate += (lt * items[i].density);
			totallength += lt;
			break;
		}
	}
	cout << "total length of wire " << totallength << endl;
	return totalrate;
}
int main()
{
	int L;
	Item items[5];
	input(items, 5);
	cout << "Enter wire length total:" << endl;
	cin >> L;
	float mxVal = WIRE(items, 3, L);
	cout << "---Maximum value for " << L << " ft. wire is " << mxVal << endl;

}
/*
Time complexity of above algorithm:
The above algorithm consists of three steps:
1)Find the density for each wire.i.e;rate/length and time complexity for that is 0(n).
2)In second step, the densities are sorted in descending order and its complexity is 0(nlogn).
3)In final step, the densities are added until the required length is achieved and its complexity in worst case will be 0(n)

Therefore, time complexity for this algorithm=0(n+nlogn+n)
                                             =0(nlogn)
*/

