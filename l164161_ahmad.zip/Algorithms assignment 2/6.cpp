#include <iostream>
#include <string>
using namespace std;
int count(int Set[], int coins, int change)
{

	if (change == 0)
		return 1;


	if (change < 0)
		return 0;


	if (coins <= 0 && change >= 1)
		return 0;


	return count(Set, coins - 1, change) + count(Set, coins, change - Set[coins - 1]);
}

int main()
{
	int i, j;
	int arr[] = { 1, 3, 5, 7 };
	int m = sizeof(arr) / sizeof(arr[0]);
	int a = count(arr, m, 9);
	cout << "distinct ways=" << a << endl;
	return 0;
}

/*
as the above code is calling two recursions in one go and there are 3 return statements
therefore T(n)=2T(n-1)+3
solving it we get
T(n)=0(2^n)
*/