#include <iostream>
#include <iomanip>
using namespace std;

int main(){
	int board[8][8];
	for (int i=0;i<8;++i){
		for (int j=0;j<8;++j){
			if (i==0 || j==0) board[i][j]=1;
			else board[i][j]=board[i-1][j]+board[i][j-1];
		}
	}
	cout << " ";
	for (int i=0;i<8;++i)
		cout << setw(5) << i+1;
	cout << endl;
	for (int i=0;i<8;++i){
		cout << i+1;
		for (int j=0;j<8;++j){
			cout << setw(5) << board[i][j];
		}
		cout << endl;
	}
	
	cout << "Moves for the other Corner: " << board[7][7] << endl;
