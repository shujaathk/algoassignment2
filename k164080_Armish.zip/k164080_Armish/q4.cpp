//question no 4 
//finding missing element in a sorted array
// "time complexity is O(n)"
#include <iostream>
using namespace std;
int missing_element (int array[], int size){
   int number;  
   number  = ((size+1)*(size+2))/2;  
   for (int i = 0; i<size; i++)    
      number -= array[i];  
   return number;
}
int main() {
   int size;   
   cout<<"Enter the size of array: "; 
   cin>>size;    
   int array[size-1];  
   cout<<"Enter array elements: ";   
   for(int i=0; i<size; i++){    
      cin>>array[i];  
   } 
   int number = missing_element(array,size);
   cout<<"Missing Number is: "<<number;
   return 0;
}
