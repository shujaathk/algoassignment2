//question no 2
//wire cutting problem
//"the time complexity of the given solution is O(n2)"

#include<iostream>
#include<climits>
 
using namespace std;
 
int max_profit(int length, int value[])
{
    int i,j;
    int profit[length+1];
    profit[0]=0;
    for(i=1;i<=length;i++)
    {
        profit[i]=INT_MIN;
        for(j=0;j<i;j++)
        {
            profit[i]=max(profit[i],value[j]+profit[i-(j+1)]);
        }
    }
    return profit[length];
}
 
int main()
{
    int length;
    cout<<"Enter the length of the rod"<<endl;
    cin>>length;
 
    int value[length-1];
    cout<<"Enter the values of pieces of rod of all size"<<endl;
    for(int i=0;i<length-1;i++)
        cin>>value[i];
 
    cout<<"Maximum profit by cutting up the rod in pieces are"<<endl;
    cout<<max_profit(length,value);
 
    cout<<endl;
    return 0;
}
