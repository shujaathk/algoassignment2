//question no 5 
//longest increasing subsequence in a sorted array
//"time complexity is exponential"

#include <iostream>
#include <climits>
using namespace std;

int LIS(int array[], int i, int size, int prev)
{
	
	if (i == size)
      	return 0;

	
	int val1 = LIS(array, i + 1, size, prev);
 
	int val2 = 0;
	if (array[i] > prev)
		val2 = 1 + LIS(array, i + 1, size, array[i]);

	return max(val1, val2);
}

int main()
{
	int array[] = { 1, 5, 6, 4, 7, 3, 2, 4, 8, 9 };
	int array_size = sizeof(array) / sizeof(array[0]);

	cout << "Length of Longest increasing subsequence is " << LIS(array, 0, array_size, INT_MIN);

	return 0;
}
