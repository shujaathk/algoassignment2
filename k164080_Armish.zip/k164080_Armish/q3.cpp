// question no 3
//longest palindrome subsequence
//"time complexity is O(n2)"
#include<iostream>
#include<cstring>

using namespace std;


int find_max(int num1, int num2)
{
	if (num1>num2)
	    return num1;
	else
	    return num2;
}
int LPS(char *string, char *sub_seq)
{
   int size = strlen(string);
   int i, j, l;                    //l is the length of the substring
   int L[size][size];  

   int Way[size][size];
   for (i = 0; i < size; i++)
   {
       L[i][i] = 1;
       Way[i][i]=0;
   }
    for (l=2; l<=size; l++)
    {
        for (i=0; i<size-l+1; i++)
        {
            j = i+l-1;
            if (string[i] == string[j] && l == 2)
            {
                   L[i][j] = 2;
                   Way[i][j]=0;     
            }

            else if (string[i] == string[j])
            {
                  L[i][j] = L[i+1][j-1] + 2;
                  Way[i][j]=0;
            }

            else
            {
                if(L[i][j-1]>L[i+1][j])
                {
                   L[i][j]=L[i][j-1];
                   Way[i][j]=1;                    
                }
                else
                {
                    L[i][j]=L[i+1][j];
                    Way[i][j]=2;  
                }

            }

        }
    }

    int index=0;
    int start=0,end=size-1;

    while(start<=end)
    {
         if(Way[start][end]==0)
         {
             sub_seq[index++]=string[start];
             start+=1;
             end-=1;

         }
         else if(Way[start][end]==1)
		    end-=1;
         else if(Way[start][end]==2)
		    start+=1;     
    }

    //int endIndex=(L[0][n-1]%2)?index-1:index;
    int end_index;
    if (L[0][size-1]%2)
        end_index=index-1;
    else
        end_index=index;
    for(int k=0;k<end_index;++k)
	sub_seq[L[0][size-1]-1-k]=sub_seq[k];

    sub_seq[index+end_index]='\0';


    return L[0][size-1];
}

int main()
{
    char string[] = "CHARACTER";
    char sub_seq[50];
    cout<<"The lnegth of the Longest palindrome subsequence is "<<LPS(string,sub_seq)<<":"<<endl;
    cout<<sub_seq<<endl;
    getchar();
    return 0;
}
