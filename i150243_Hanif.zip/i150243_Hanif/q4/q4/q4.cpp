#include <iostream>
using namespace std;
void findnum(int arr[], int size);

int main()
{
	int size = 0;
	cout << "Enter the size of the array: ";
	cin >> size;
	int arr[size];
	cout << endl;
	cout << "Enter the values for the sorted manner: " << endl;
	for (int i = 0; i<size; i++)
	{
		cin >> arr[i];
	}
	findnum(arr, size);
	return 0;
}
void findnum(int arr[], int size)
{
	int missing_num = 0;
	int first = 0;
	int last = size - 1;
	int middle = 0;
	int val1 = 0;
	int val2 = 0;
	int val3 = 0;

	while ((last - first) > 1)
	{
		middle = (first + last) / 2;
		val1 = arr[first] - first;
		val2 = arr[middle] - middle;
		val3 = arr[last] - last;
		if (val1 != val2)
		{
			last = middle;
		}
		else if (val3 != val2)
		{
			first = middle;
		}
	}

	missing_num = (arr[middle] + 1);
	cout << "First Missing Number: " << missing_num << endl;
	cout << "Running time: O(n)" << endl;
}