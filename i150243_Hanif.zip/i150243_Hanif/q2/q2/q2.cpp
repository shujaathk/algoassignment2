#include<iostream>
using namespace std;
void func(int rate[], int n);
int main()
{
	int n = 0;
	cout << "Please enter the length of the wire: ";
	cin >> n;
	cout << endl;
	int arr[n];

	cout << "Enter the rate for the lengths of the wire " << endl;
	for (int i = 0; i<n; i++)
	{
		cout << "Length:" << i + 1 << " Rate = ";
		cin >> arr[i];
	}
	func(arr, n);
	return 0;
}
void func(int rate[], int n)
{
	int i = 0;
	int wu;
	int w_arr[n + 1];
	int v_arr[n + 1];
	int l_arr[n + 1];
	v_arr[0] = 0;
	while (i <= n)
	{
		int max = -1;
		int b_len = -1;
		for (int j = 0; j < i; j++)
		{
			if (max <rate[j] + v_arr[i - j - 1])
			{
				max = rate[j] + v_arr[i - j - 1];
				b_len = j;
			}
		}
		v_arr[i] = max;
		l_arr[i] = b_len + 1;
		i++;
	}
	int x = 0;
	for (i = n, i>0; i -= l_arr[i])
	{
		w_arr[x++] = l_arr[i];
	}
	wu = x;

	cout << "Result: " << v_arr[n];
	cout << " by cutting rod in pieces of sizes: ";
	for (int i = 0; i<wu; i++)
	{
		cout << w_arr[i] << " ";
	}
	cout << endl;
	cout << "Running time of Algorithm: O(n^2).";
}