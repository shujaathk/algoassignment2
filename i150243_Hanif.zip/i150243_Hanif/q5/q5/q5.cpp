#include<iostream>
#include<math.h>
using namespace std;
void func(int input_array[], int n);
int main()
{
	int size = 0;
	cout << "Enter the size of the array:";
	cin >> size;

	cout << endl;

	int input_array[size];
	cout << "Enter the values: ";
	for (int i = 0; i<size; i++)
	{
		cin >> input_array[i];
		cout << endl;
	}
	func(input_array, size);
	return 0;
}


void func(int input_array[], int n)
{
	int temparr[n];
	int arr[n + 1];
	int length = 0,
		int z = 0;
	int first = 0
		int last = 0
		int mid = 0;

	for (int i = 0; i<n; i++)
	{
		first = 1;
		last = length;
		while (first <= last)
		{
			mid = ceil((first + last) / 2);
			if (input_array[arr[mid]] <= input_array[i])
			{
				first = mid + 1;
			}
			else
			{
				last = mid - 1;
			}
		}
		z = first;
		temparr[i] = arr[z - 1];
		arr[z] = i;

		if (z > length)
		{
			length = z;
		}
	}
	int a = 0;
	int subsequence[length];
	a = arr[length];

	cout << endl;

	for (int i = length - 1; i >= 0; i--)
	{
		subsequence[i] = input_array[a];
		a = temparr[a];
	}
	cout << "Length of longest non consecutive increasing subsequence is: " << length;
	cout << " and the subsequence is:[ ";
	for (int i = 0; i<length; i++)
	{
		cout << subsequence[i] << " ";
	}
	cout << "]" << endl;
	cout << "Running time of algorithm is: O(nlogn)" << endl;
}