#include<iostream>
#include<string>
#include<algorithm>

using namespace std;

#define n 30
int arr[n][n];
string f_Pal(string str, string str_rev, int str_len, int str_rev);
int main()
{
	string str;
	string str_rev;
	cout << "Please enter the input string: ";
	cin >> str;
	int str_len = str.length();

	for (int i = str.length() - 1; i >= 0; i--)
	{
		str_rev += str[i];
	}
	strReverse_len = str_rev.length();

	for (int i = 0; i <= str_len; i++)
	{
		for (int j = 0; j <= str_len; j++)
		{
			if (i == 0 || j == 0)
			{
				arr[i][j] = 0;
			}
			if (str[i - 1] == str_rev[j - 1])
			{
				arr[i][j] = arr[i - 1][j - 1] + 1;
			}
			else
			{
				arr[i][j] = max(arr[i - 1][j], arr[i][j - 1]);
			}
		}
	}

	string l_Pal = f_Pal(str, str_rev, str_len, str_rev);
	cout << "Palindrome Subsequence: " << l_Pal << endl;
	cout << "Running time: O(n^2)" << endl;
	return 0;
}

string f_Pal(string str, string str_rev, int str_len, int str_rev)
{
	if (str_len == 0 || str_rev == 0)
	{
		return string("");
	}

	if (str[str_len - 1] == str_rev[str_rev - 1])
	{
		return f_Pal(str, str_rev, str_len - 1, str_rev - 1) + str[str_len - 1];
	}

	if (arr[str_len - 1][str_rev]>arr[str_len][str_rev - 1])
	{
		return f_Pal(str, str_rev, str_len - 1, str_rev);
	}
	return f_Pal(str, str_rev, str_len, str_rev - 1);
}